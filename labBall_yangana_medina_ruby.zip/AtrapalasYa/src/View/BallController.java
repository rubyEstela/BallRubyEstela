package View;



import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Scanner;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Arc;
import javafx.scene.shape.ArcType;
import javafx.scene.shape.Circle;
import javafx.stage.Stage;
import model.Ball;
import model.Game;
import model.Player;
import model.Score;

import threads.BallThread;

public class BallController {

	@FXML
	private Circle blueCircle;

	@FXML
	private AnchorPane ap;
	private Stage stage;
	private Game game;
	@FXML
	private AnchorPane ap2;
	@FXML
	private ArrayList<Circle> circulo;
	@FXML
	private Label rebounds;
	private int score;
	private Ball ball;

	public void setStage(Stage stage) {
		this.stage = stage;
	}

	public double getWidth() {
		return stage.getWidth();
	}

	@FXML
	public void loadGame(ActionEvent event) throws IOException, ClassNotFoundException {
		game = new Game(0);

		circulo = new ArrayList<>();
		for (int i = 0; i < game.getBall().size(); i++) {
			Arc ar = new Arc(game.getBall().get(i).getPosX(), game.getBall().get(i).getPosY(),
					game.getBall().get(i).getRadio(), game.getBall().get(i).getRadio(), 45, 270);
			ar.setType(ArcType.ROUND);
			ar.setFill(Color.YELLOW);
			circulo.add(null);
		}
		ap2.getChildren().addAll(circulo);
		BallThread ct = new BallThread(this, game);
		ct.start();
		rebounds.setText("" + game.totalRebounds());
		score = score - game.totalRebounds() * 10;
	}

	@FXML
	public void stop(MouseEvent event) {
		double x = event.getSceneX();
		double y = event.getSceneY();
		for (int i = 0; i < game.getBall().size(); i++) {
			game.getBall().get(i).stopBall(x, y);
		}
		score = score + 50;
	}

	public void updateBalls() {
		for (int i = 0; i < game.getBall().size(); i++) {
			circulo.get(i).setLayoutX(game.getBall().get(i).getPosX());
			circulo.get(i).setLayoutY(game.getBall().get(i).getPosY());
		}

	}

	@FXML
	void saveGame(ActionEvent event) throws FileNotFoundException, IOException {
		game.saveGame();
		System.out.println("Name: ");
		Scanner sn = new Scanner(System.in);
		String name = sn.nextLine();
		Player p = new Player(name);
		Score s = new Score(p, score);
		game.getScores().add(s);
	}

	@FXML
	void betterScores(ActionEvent event) {
		Label l = new Label();
		l.setText(game.betterScores());
		ap2.getChildren().add(l);
	}

}

