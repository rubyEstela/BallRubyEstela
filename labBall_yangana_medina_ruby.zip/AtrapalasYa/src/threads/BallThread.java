package threads;

import View.BallController;
import model.Game;

public class BallThread {
	
	private  BallController pc ;
	private Game g;
	
	public BallThread(BallController pc, Game g) {
		pc=pc;
		this.g=g;
	}
	public void run() throws InterruptedException {
		while(true) {
			for(int i = 0; i<g.getBall().size(); i++) {
				g.getBall().get(i).move(pc.getWidth());
				pc.updateBalls();
				g.totalRebounds();
				sleep((long) g.getBall().get(i).getWait());
			}
		}
	
}
	private void sleep(long wait) {
		// TODO Auto-generated method stub
		
	}
	public void start() {
		
		// TODO Auto-generated method stub
		
	}
	
	
}
	
	
	
	
	
	


