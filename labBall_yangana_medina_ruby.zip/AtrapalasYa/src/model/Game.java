package model;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.io.PrintWriter;

public class Game {
	
	private ArrayList<Ball> balls;
	private int level;
	
	private final static  String PATH_FILE= "data/levels";
	
	private ArrayList<Score> score;
	
	public Game(int l) {
		balls = new ArrayList<>();
		level = l;
		score = new ArrayList<>();
	}
	
	
	
	

	public Game(String name) {
		// TODO Auto-generated constructor stub
	}




	public void startGame() throws IOException, ClassNotFoundException {
		File archive = new File(PATH_FILE);
		FileReader reader = new FileReader(archive);
		BufferedReader br = new BufferedReader(reader);
		String ln = br.readLine();
		String dif = "#";
		int i = 0;
				while(ln != null) {
					String[] parts = ln.split(";");
					double radio =Double.parseDouble(parts[0]);
					double posX = Double.parseDouble(parts[1]);
					double posY = Double.parseDouble(parts[2]);
					double wait = Double.parseDouble(parts[3]);
					int direction = Integer.parseInt(parts[4]);
					int rebounds = Integer.parseInt(parts[5]);
					boolean state = Boolean.valueOf(parts[6]);
					Ball pc = new Ball(radio, posX, posY, wait, direction, rebounds, state);
					balls.add(pc);
					ln = br.readLine();
					i++;
				}
			reader.close();
			br.close();

	}
	
	public ArrayList<Ball>getBall(){
		return balls;
	}
	
	public int totalRebounds() {
		int totalRebounds=0;
		for (int i = 0; i < balls.size(); i++) {
			totalRebounds=totalRebounds+balls.get(i).getRebounds();
		}
		return totalRebounds;
	}
	
	public void saveGame() throws FileNotFoundException, IOException {
		File archive = new File(PATH_FILE);
		ObjectOutputStream os = new ObjectOutputStream(new FileOutputStream(archive));
		os.writeObject(balls);
		PrintWriter pw = new PrintWriter(archive);
		pw.print(os);
		os.close();
		pw.close();
	}
	public String betterScores() {
		String message = "";
		for(int i = 0; i<score.size(); i++) {
			if(score.get(i).getValue() > score.get(i-1).getValue()) {
				message = ("Better Score: " + score.get(i).getValue() + "Player: " + score.get(i).getPlayer());
			}
		}
		return message;
	}
	public ArrayList<Score> getScores(){
		return score;
	}

	
	

}
