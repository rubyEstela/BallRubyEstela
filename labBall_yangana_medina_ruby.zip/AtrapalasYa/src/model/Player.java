package model;

public class Player {
	
	private String name;
	public Player(String n) {
		name=n;
	}
	public String getName() {
		return name;
	}


}

