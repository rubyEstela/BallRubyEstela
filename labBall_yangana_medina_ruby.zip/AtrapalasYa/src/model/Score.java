package model;

import java.io.Serializable;

public class Score implements Serializable {

	private Game player;
	private int value;
	public Score(Game s, int v) {
		player=s;
		value=v;
	}

	public Score(Player p, int totalRebounds) {
		// TODO Auto-generated constructor stub
	}

	public Game getPlayer() {
		return player;
	}
	public int getValue() {
		return value;
	}
	
}

